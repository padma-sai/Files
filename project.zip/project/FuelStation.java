/* Java Project for Fuel station
In this program we can experience the Fuel station management.
First we have to enter Fuel type.
Next we need select the type to give the input
(Like)
Petrol(Fuel type)
litres(input method)
Bill(displays).
Done by
B.padmasai.
51834617
  */
import java.util.*;
public class FuelStations extends Menu
{
  public static void main(String [] args)
  {
  //creating a 's' variable to call the menu
    Menu s = new Menu();  
    s.getinfo();
  }
}
class Menu extends Bunk
{
  Scanner sc= new Scanner(System.in);
  //creating a method
  public void getinfo()
  {
  System.out.println("welcome to HP Fuel Station");
  System.out.println("1.Petrol");
  System.out.println("2.Diesel");
  System.out.println("3.Tank full");
  System.out.println("4.exit");
  System.out.println("select one option");
   int choice = sc.nextInt();
  //using switch case to select the options
   switch (choice)
   {
     case 1:
       getPetrol();
       break;
     case 2:
       getDiesel();
       break;
     case 3:
         gettankFill();
         break;
     case 4:
       System.out.println("Thank you for visiting");
       break;
     default:
       System.out.println("Enter valid option");
       getinfo();
    }
   }
   public void getPetrol()
   {
     System.out.println("1.Litres");
     System.out.println("2.Amount");
     System.out.println("3.Exit");
    System.out.println("select your option");
     int choice = sc.nextInt();
     
      switch (choice)
      {
        case 1:
          getpetrolltrs();//This method for giving petrol data in quantity
          getPayment();
          
          break;
        case 2:
          getpetrolMoney();//This method for giving petrol data in money
          getPayment();
          break;
        case 3:
             System.out.println("Thank you");
          break;
        default:
          System.out.println("Invalid choice");
         
          getPetrol();
      }
   }
   public void getDiesel()
   {
     System.out.println("1.Litres");
     System.out.println("2.Amount");
     System.out.println("3.Exit");
     System.out.println("select your option");
     int choice = sc.nextInt();
     
      switch (choice)
      {
        case 1:
          getDieselltrs();//This method for giving diesel data in quantity
          getPayment();
          break;
        case 2:
          getDieselMoney();//This method for giving diesel data in money
          getPayment();
          break;
        case 3:
          System.out.println("Thank you");
          break;
        default:
          System.out.println("Invalid choice");
         
          getDiesel();
      }
   }
}
class Bunk
{
  //initialising the varaibles
  Scanner a = new Scanner(System.in);
  double litres;
  double Amount;
  double petrolCost = 83.16;
  double  dieselCost = 79.03;
// In this method user enters quantity size
  public void getpetrolltrs()
  {
    System.out.println("Enter no of litre's");
    litres = a.nextDouble();
    if (litres>=0)
    {
      Amount = litres*petrolCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
    }
    else
    {
      System.out.println("Enter the value more than 0");
    }
  }
//In this method user enters the money
  public void getpetrolMoney()
  {
    System.out.println("Enter the money");
    Amount = a.nextDouble();
    if (Amount>=0)
    {
      litres = Amount/petrolCost;//It calculates how many litres he will get
      System.out.println(litres+" litre's be filled");
    }
    else
    {
      System.out.println("Enter the correct Amount");
    }
  }
  public void getDieselltrs()
  {
    System.out.println("Enter no of litre's");
    litres = a.nextDouble();
    if (litres>=0)
    {
      Amount = litres*dieselCost;
      System.out.println(Amount+" should be paid");
    }
    else
    {
      System.out.println("Enter the value more than 0");
    }
  }
  public void getDieselMoney()
  {
    System.out.println("Enter the money");
    Amount = a.nextDouble();
    if (Amount>=0)
    {
      litres = Amount/dieselCost;
      System.out.println(litres+" litre's be filled");
    }
    else
    {
      System.out.println("Enter the correct Amount");
    }
  }
public void getPayment()
{
System.out.println("payment mode");
System.out.println("1.card");
System.out.println("2.cash");
System.out.println("3.exit");
System.out.println("select your option");
 int choice = a.nextInt();
     
      switch (choice)
      {
        case 1:
          getCard();
          break;
        case 2:
try{ 
System.out.println("Please deposite the amount in machine");
Thread.sleep(5000);
System.out.println("fuel is filling");
Thread.sleep(1000);
System.out.println("Thank you for visiting");
Thread.sleep(1000);
}catch(InterruptedException e){
System.out.println(e);
}  
break;
        case 3:
          System.out.println("Thank you");
          break;
        default:
          System.out.println("Invalid choice");
      }
}

public void getCard()
{
Scanner p = new Scanner(System.in);
System.out.println("please enter card number");
long cardNo =p.nextLong();
System.out.println("enter cvv number");
int cvv = p.nextInt();
System.out.println("your card no is"+cardNo);
System.out.println("your cvv no is"+cvv);
System.out.println("please acccept the payment");
try{
Thread.sleep(5000); 
System.out.println("payment successful");
Thread.sleep(1000);
System.out.println("fuel is filling");
Thread.sleep(1000);
System.out.println("Thank you for visiting");
Thread.sleep(1000);
}catch(InterruptedException e){
System.out.println(e);
}  
}
public void gettankFill()
{
System.out.println("1.Bike\n2.Car\n3.Auto\n4.Lorry");
System.out.println("enter your option");
int choice = a.nextInt();
switch(choice){
case 1:
litres = 10;
Amount = litres*petrolCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
 getPayment();
break;
case 2:
Scanner d = new Scanner(System.in);
litres = 25;
System.out.println("enter type \n1.petrol\n2.diesel");
System.out.println("enter your option");
int type = d.nextInt();
if(type== 1){
Amount = litres*petrolCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
 getPayment();
}
else if(type ==2){
Amount = litres*dieselCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
 getPayment();
}
else{
System.out.println("enter valid option");
}
break;
case 3:
Scanner c = new Scanner(System.in);
litres = 9;
System.out.println("enter type \n1.petrol\n2.diesel");
System.out.println("enter your option");
type = c.nextInt();
if(type==1){
Amount = litres*petrolCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
 getPayment();
}
else if(type ==2){
Amount = litres*dieselCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
 getPayment();
}
else{
System.out.println("enter valid option");
}
break;
case 4:
litres = 150;
Amount = litres*dieselCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
 getPayment();
break;
default:
System.out.println("enter valid option");
}
}
}


=========================================================================================================
/* Java Project for Fuel station
In this program we can experience the Fuel station management.
First we have to enter Fuel type.
Next we need select the type to give the input
(Like)
Petrol(Fuel type)
litres(input method)
Bill(displays).
Done by
B.padmasai.
51834617
  */
import java.util.*;
public class FuelStation extends Menu
{
  public static void main(String [] args)
  {
  //creating a 's' variable to call the menu
    Menu s = new Menu();  
    s.getinfo();
  }
}
class Menu extends Bunk
{
  Scanner sc= new Scanner(System.in);
  //creating a method
  public void getinfo()
  {
  System.out.println("welcome to HP Fuel Station");
  System.out.println("1.Petrol");
  System.out.println("2.Diesel");
  System.out.println("3.Tank full");
  System.out.println("4.exit");
  System.out.println("select one option");
   int choice = sc.nextInt();
  //using switch case to select the options
   switch (choice)
   {
     case 1:
       getPetrol();
       break;
     case 2:
       getDiesel();
       break;
     case 3:
         gettankFill();
         getPayment();
         break;
     case 4:
       System.out.println("Thank you for visiting");
       break;
     default:
       System.out.println("Enter valid option");
       getinfo();
    }
   }
   public void getPetrol()
   {
     System.out.println("1.Litres");
     System.out.println("2.Amount");
     System.out.println("3.Exit");
    System.out.println("select your option");
     int choice = sc.nextInt();
     
      switch (choice)
      {
        case 1:
          getpetrolltrs();//This method for giving petrol data in quantity
          getPayment();
          
          break;
        case 2:
          getpetrolMoney();//This method for giving petrol data in money
          getPayment();
          break;
        case 3:
             System.out.println("Thank you");
          break;
        default:
          System.out.println("Invalid choice");
         
          getPetrol();
      }
   }
   public void getDiesel()
   {
     System.out.println("1.Litres");
     System.out.println("2.Amount");
     System.out.println("3.Exit");
     System.out.println("select your option");
     int choice = sc.nextInt();
     
      switch (choice)
      {
        case 1:
          getDieselltrs();//This method for giving diesel data in quantity
          getPayment();
          break;
        case 2:
          getDieselMoney();//This method for giving diesel data in money
          getPayment();
          break;
        case 3:
          System.out.println("Thank you");
          break;
        default:
          System.out.println("Invalid choice");
         
          getDiesel();
      }
   }
}
class Bunk
{
  //initialising the varaibles
  Scanner a = new Scanner(System.in);
  double litres;
  double Amount;
  double petrolCost = 83.16;
  double  dieselCost = 79.03;
// In this method user enters quantity size
  public void getpetrolltrs()
  {
    System.out.println("Enter no of litre's");
    litres = a.nextDouble();
    if (litres>=0)
    {
      Amount = litres*petrolCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
    }
    else
    {
      System.out.println("Enter the value more than 0");
    }
  }
//In this method user enters the money
  public void getpetrolMoney()
  {
    System.out.println("Enter the money");
    Amount = a.nextDouble();
    if (Amount>=0)
    {
      litres = Amount/petrolCost;//It calculates how many litres he will get
      System.out.println(litres+" litre's be filled");
    }
    else
    {
      System.out.println("Enter the correct Amount");
    }
  }
  public void getDieselltrs()
  {
    System.out.println("Enter no of litre's");
    litres = a.nextDouble();
    if (litres>=0)
    {
      Amount = litres*dieselCost;
      System.out.println(Amount+" should be paid");
    }
    else
    {
      System.out.println("Enter the value more than 0");
    }
  }
  public void getDieselMoney()
  {
    System.out.println("Enter the money");
    Amount = a.nextDouble();
    if (Amount>=0)
    {
      litres = Amount/dieselCost;
      System.out.println(litres+" litre's be filled");
    }
    else
    {
      System.out.println("Enter the correct Amount");
    }
  }
public void getPayment()
{
System.out.println("payment mode");
System.out.println("1.card");
System.out.println("2.cash");
System.out.println("3.exit");
System.out.println("select your option");
 int choice = a.nextInt();
     
      switch (choice)
      {
        case 1:
          getCard();
          break;
        case 2:
           System.out.println("Please deposite the amount in machine");
            
           System.out.println("fuel is filling");
            
           System.out.println("Thank you for visiting");
          break;
        case 3:
          System.out.println("Thank you");
          break;
        default:
          System.out.println("Invalid choice");
      }
}

public void getCard()
{
Scanner p = new Scanner(System.in);
System.out.println("please enter card number");
long cardNo =p.nextLong();
System.out.println("enter cvv number");
int cvv = p.nextInt();
System.out.println("your card no is"+cardNo);
System.out.println("your cvv no is"+cvv);
System.out.println("please acccept the payment");

System.out.println("payment successful");

System.out.println("fuel is filling");

           System.out.println("Thank you for visiting");

}
public void gettankFill()
{
System.out.println("1.Bike\n2.Car\n3.Auto\n4.Lorry");
int choice = a.nextInt();
switch(choice){
case 1:
litres = 10;
Amount = litres*petrolCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
break;
case 2:
litres = 25;
System.out.println("enter type petrol or disel");
String type = a.nextLine();
if(type=="petrol"){
Amount = litres*petrolCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
}
else{
Amount = litres*dieselCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
}
break;
case 3:
litres = 9;
System.out.println("enter type petrol or disel");
type = a.nextLine();
if(type=="petrol"){
Amount = litres*petrolCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
}
else{
Amount = litres*dieselCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
}

break;
case 4:
litres = 150;
Amount = litres*dieselCost;//It calculates the money for given quantity
      System.out.println(Amount+" should be paid");
break;
default:
System.out.println("enter valid option");
}


}
}
