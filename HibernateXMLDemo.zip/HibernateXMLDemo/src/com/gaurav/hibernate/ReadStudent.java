package com.gaurav.hibernate;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.gaurav.hibernate.entity.Student;

public class ReadStudent {

	public static void main(String[] args) {
		// Create SessionFactory
		
		SessionFactory factory=new Configuration()
				               .configure("hibernate.cfg.xml")
				               .addAnnotatedClass(Student.class)
				               .buildSessionFactory();
	
       
		
		try
		{
			
			
			//Reading an object using primary key
			//get a new session
			Session session=factory.getCurrentSession();
			session.beginTransaction();
			
			//retrieve student based on id-peimary key
			
			Student myStudent=(Student)session.get(Student.class,1);
			System.out.println("\nGet Complete : "+myStudent);
			
			//commit the transaction
			
			session.getTransaction().commit();
			
			System.out.println("Done");
			
			
		}
		finally
		{
			factory.close();
		}

	}

}
