package com.gaurav.hibernate;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.gaurav.hibernate.entity.Student;

public class CreateStudentDemo {

	public static void main(String[] args) {
		// Create SessionFactory
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		
		
		/*SessionFactory factory=new Configuration()
				               .configure("hibernate.cfg.xml")
				               .addAnnotatedClass(Student.class)
				               .buildSessionFactory();*/
		//create Session
		
		/*Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory factory=cfg.buildSessionFactory();*/
		//Session session=factory.openSession();
		
		Session session=factory.getCurrentSession();
		
		try
		{
			//use Session object to save the Java object
			
			//create Student object
			System.out.println("creating a Student object");
			Student tempStudent=new Student(105,"Cathy","Sierra","cathy@gmail.com");
			
			//start transaction
			session.beginTransaction();
			
			//save Student object
			System.out.println("Saving Student Object");
			session.save(tempStudent);
			//session.delete(tempStudent);
			//session.update(tempStudent);
			
			//commit transaction
			session.getTransaction().commit();
			
			System.out.println("Done");
			
			
		}
		finally
		{
			factory.close();
		}

	}

}
