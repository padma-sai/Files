import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import entity.Car;
import entity.Engine;

public class DeleteEntityMain {

	public static void main(String[] args) {
	      
		//Creating SessionFactory object
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Car.class).addAnnotatedClass(Engine.class).buildSessionFactory();
		
		//create Session object using SessionFactory object
		Session session=factory.getCurrentSession();
				
		session.beginTransaction();
		Car c1=(Car)session.get(Car.class, 1);
		
		session.delete(c1);
		
		
		session.getTransaction().commit();
		System.out.println("Car Object Deleted!");
        
	}


}
