package main;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import entity.Scholar;
public class MainClass
{
	public static void main(String[] args) {
      
		//Creating SessionFactory object
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Scholar.class).buildSessionFactory();
		
        /* Configuration config=new Configuration();
         * config.configure("hibernate.cfg.xml");
         * config.addAnnotatedClass(Scholar.class);
         * SessionFactory factory=config.buildSessionFactory(); 		
         */
		
		//create Session object using SessionFactory object
		Session session=factory.getCurrentSession();
		Scholar s1=new Scholar("Neel","Testing","Guntur");
		Scholar s2=new Scholar("Kathy","Java","Vijayawada");
		
		session.beginTransaction();
		session.save(s1);
		session.save(s2);
		session.getTransaction().commit();
		
        System.out.println("Scholar Objects are persisted!!");
	}

}
