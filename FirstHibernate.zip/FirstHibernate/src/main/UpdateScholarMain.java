package main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Scholar;

public class UpdateScholarMain {

	public static void main(String[] args) {
	      
		//Creating SessionFactory object
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Scholar.class).buildSessionFactory();
		
        	
		//create Session object using SessionFactory object
		Session session=factory.getCurrentSession();
		
        		
		
		session.beginTransaction();
		Scholar s1=(Scholar)session.get(Scholar.class, 3);
		
		s1.setCity("Vijayawada");
		s1.setCourse("Java");
		
		session.update(s1);
		
		
		
		session.getTransaction().commit();
		System.out.println("Scholar Updated : "+s1);
		
       
	}

}
