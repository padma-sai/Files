import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Scholar;

public class HQLPagination {

public static void main(String[] args) {
	      
		
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Scholar.class).addAnnotatedClass(ScholarTemp.class).buildSessionFactory();
		
       	Session session=factory.getCurrentSession();
    	session.beginTransaction();
    	  String hql = "from Scholar";
    	  Query query = session.createQuery(hql);
    	  query.setFirstResult(2);
    	  query.setMaxResults(2);
    	  
    	  List<Scholar> listProducts = query.list();
    	 
    	  for (Scholar sch : listProducts) {
    	    System.out.println(sch.getSchName()+"\t"+sch.getCity());
    	   }

		
       	session.getTransaction().commit();
      
		
        
	}


}
