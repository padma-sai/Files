package main;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import entity.*;
public class MainClass
{
	public static void main(String[] args) {
      
		//Creating SessionFactory object
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Car.class).addAnnotatedClass(Engine.class).buildSessionFactory();
		
		//create Session object using SessionFactory object
		Session session=factory.getCurrentSession();
		
		Car c1=new Car();
		c1.setCarId(1);
		c1.setModel("Ameo");
	
		
		Engine e1=new Engine();
		e1.setEngineId(100);
		e1.setPower(1200);
		e1.setType("Petrol");
		
		
		c1.setEngine(e1);
		e1.setCar(c1);
		
		
		
		session.beginTransaction();
		session.save(e1);
		session.getTransaction().commit();
		System.out.println("Object Saved!!");
        
	}

}
