package com.gaurav.entity;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="temp2")
public class Employee {
	

	@Id
	@Column(name="eno")
	private int eno;
	
	@Column(name="ename")
	private String ename;
	
	@Temporal(TemporalType.DATE)
	@Column(name="doj")
	private Date doj;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="dol")
	private Date dol;
	
	public Employee(){}

	public Employee(int eno, String ename, Date doj, Date dol) {
		super();
		this.eno = eno;
		this.ename = ename;
		this.doj = doj;
		this.dol = dol;
	}

	public int getEno() {
		return eno;
	}

	public void setEno(int eno) {
		this.eno = eno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public Date getDol() {
		return dol;
	}

	public void setDol(Date dol) {
		this.dol = dol;
	}
	

	
}
