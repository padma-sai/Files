package com.gaurav.main;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.gaurav.entity.*;

public class TestClass {
	
	public static void main(String[] args)
	{
		SessionFactory factory=new Configuration()
	               .configure("hibernate.cfg.xml")
	               .addAnnotatedClass(Employee.class)
	               .buildSessionFactory();
    factory.openSession();

Session session=factory.getCurrentSession();

try
{
//use Session object to save the Java object

//create Student object
System.out.println("creating a Student object");
Employee emp=new Employee(101,"Nidhi Goel",new Date(),new Date());

//start transaction
session.beginTransaction();

//save Student object
System.out.println("Saving Student Object");
session.save(emp);
//session.delete(tempStudent);
//session.update(tempStudent);

//commit transaction
session.getTransaction().commit();

System.out.println("Done");


}
finally
{
factory.close();
}

	}

}
