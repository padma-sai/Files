package com;

class ascending extends Thread{
	public void run(){
		for(int i =1;i<11;i++){
			System.out.println(i);
		}
	}
}
class descending extends Thread{
	public void run(){
		try{Thread.sleep(5000);}catch(Exception e){System.out.println(e);}  
		for(int i=10;i>0;i--){
			 
			System.out.println(i);
		}
	}
}
public class Threading {
public static void main(String[]args){
	ascending a = new ascending();
	descending d = new descending();
	a.start();
	d.start();  //Sleep(try catch )
	
}
}
