package com;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.SequenceInputStream;

public class IO {

	public static void main(String[] args) {
		/*try{
		FileOutputStream f = new FileOutputStream("C:\\Users\\shaik.muneer\\Desktop\\Sai1.txt");	
		BufferedOutputStream n = new BufferedOutputStream(f);
		String s ="Sai is a FREE FIRE Player";
		byte b[] = s.getBytes();
		n.write(b);
		n.close();
		f.close();
		System.out.println("success");
		 
		FileInputStream fin=new FileInputStream("C:\\Users\\shaik.muneer\\Desktop\\Sai1.txt");	
		BufferedInputStream bv = new BufferedInputStream(fin);
           int i=0;    
           while((i=bv.read())!=-1){    
            System.out.print((char)i);    
           }    
           bv.close();
           fin.close();    
		}
		
catch(Exception e){
	System.out.println(e);
}*/
		try{
		   FileInputStream fin1=new FileInputStream("C:\\Users\\shaik.muneer\\Desktop\\Sai.txt");    
		   FileInputStream fin2=new FileInputStream("C:\\Users\\shaik.muneer\\Desktop\\Sai1.txt");    
		   FileOutputStream fout=new FileOutputStream("C:\\Users\\shaik.muneer\\Desktop\\IO.txt");      
		   SequenceInputStream sis=new SequenceInputStream(fin1,fin2);    
		   int i;    
		   while((i=sis.read())!=-1)    
		   {    
		     fout.write(i);        
		   }    
		   sis.close();    
		   fout.close();      
		   fin1.close();      
		   fin2.close();       
		   System.out.println("Success..");
}
catch(Exception e){
     System.out.println(e);	
}
	}

}
