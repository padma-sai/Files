package com;
import java.util.*;
public class Eggs {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter the number of eggs");
	int eggs = sc.nextInt();
	int g = eggs/144;
	int r = eggs%144;
	int d = r/12;
	int left = r%12;
	System.out.println("Gross: "+g+" Dozen: "+d+" and "+left);
	}

}
