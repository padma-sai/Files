package com;
import java.util.*;
public class Collections {
public static void main(String[] args){
	Student st1 = new Student(1,"sravanthi",1245,"mecs");
	Student st2 = new Student(2,"AdNi",234567,"1stclass");
	Student st3 = new Student (3,"Somaraju",43833,"Nursery");
	List<Student> a = new ArrayList();
	a.add(st1);
	a.add(st2);
	a.add(st3);
//	for(Student arr:a){
//		System.out.println(arr);
//	}
//	
	 Iterator itr=a.iterator();
	 while(itr.hasNext()){
		System.out.println(itr.next()); 
	 }

}
}
