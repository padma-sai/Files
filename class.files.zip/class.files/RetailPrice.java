package com;
import java.util.*;
public class RetailPrice {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("enter product no:");
	int id = sc.nextInt();
	switch(id){
	case 1:
		System.out.println("product id:"+id);
		System.out.println("enter the Quantity");
		int q = sc.nextInt();
		System.out.println("Quantity : "+q);
		double price  = 22.50;
		double amount= q*price;
		System.out.println("Your total retail value of "+id+" is "+amount);
	    break;
	case 2:
		System.out.println("product id:"+id);
		System.out.println("enter the Quantity");
		int qu = sc.nextInt();
		System.out.println("Quantity : "+qu);
		double cost  = 44.50;
		double amou= qu*cost;
		System.out.println("Your total retail value of "+id+" is "+amou);
	    break;  
	case 3:
		System.out.println("product id:"+id);
		System.out.println("enter the Quantity");
		int qua = sc.nextInt();
		System.out.println("Quantity : "+qua);
		double prices  = 9.98;
		double a= qua*prices;
		System.out.println("Your total retail value of "+id+" is "+a);
	    break;
	    default:
	    	System.out.println("There is no product with this id:"+id);
	}
	}
}

