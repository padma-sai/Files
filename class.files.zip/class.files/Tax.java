package com;
import java.util.*;
public class Tax {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("INCOME TAX");
	System.out.println("1.GENERAL");
	System.out.println("2.WOMEN");
	System.out.println("3.EXIT");
	System.out.println("SELECT ONE OPTION");
	int option = sc.nextInt();
	switch(option){
	case 1:
	System.out.println("enter your income");
	int income = sc.nextInt();
	if( income>= 0 &&income<= 180000 ){
		System.out.println("no Tax");
	}
	else if( income>= 180001 && income<=500000){
		System.out.println("tax is 10%");
		int tax = (int) (income*0.1);
		System.out.println("tax amount:"+tax);
	}
	else if( income>= 500001 && income<=800000){
		System.out.println("tax is 10%");
		int tax = (int) (income*0.2);
		System.out.println("tax amount:"+tax);
	}
	else if( income>800000){
		System.out.println("tax is 10%");
		int tax = (int) (income*0.3);
		System.out.println("tax amount:"+tax);
	}
	else if( income<0){
		System.out.println("Enter number greater than 0");
	}
	else{
		System.out.println("enter correct value");
	}
	break;
	case 2:
		System.out.println("enter your income");
		int incomes = sc.nextInt();
		if( incomes>= 0 &&incomes<= 190000 ){
			System.out.println("no Tax");
		}
		else if( incomes>= 190001 && incomes<=500000){
			System.out.println("tax is 10%");
			int tax = (int) (incomes*0.1);
			System.out.println("tax amount:"+tax);
		}
		else if( incomes>= 500001 && incomes<=800000){
			System.out.println("tax is 10%");
			int tax = (int) (incomes*0.2);
			System.out.println("tax amount:"+tax);
		}
		else if( incomes>800000){
			System.out.println("tax is 10%");
			int tax = (int) (incomes*0.3);
			System.out.println("tax amount:"+tax);
		}
		else if( incomes<0){
			System.out.println("Enter number greater than 0");
		}
		else{
			System.out.println("enter correct value");
		}
		break;
	case 3:
		System.out.println("Thank You");
		break;
		default:
			System.out.println("enter correct option");
	}
}
}
