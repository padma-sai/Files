package com;

import java.util.Scanner;

public class PalindromePrime {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		 int r,sum=0,temp;  
		 System.out.println("Enter the number");
		  int n=sc.nextInt();//It is the number variable to be checked for palindrome  
		  int x = n;
		  temp=n;    
		  while(n>0){    
		   r=n%10;  //getting remainder  
		   sum=(sum*10)+r;    
		   n=n/10;    
		  }    
		  if(temp==sum)    
		   System.out.println("palindrome number ");    
		  else    
		   System.out.println("not palindrome");  
		  
		  int i,m=0,flag=0;      
		 System.out.println(x);
		  m=x/2;      
		  if(x==0||x==1){  
		   System.out.println(x+" is not prime number");      
		  }else{  
		   for(i=2;i<=m;i++){      
		    if(x%i==0){      
		     System.out.println(x+" is not prime number");      
		     flag=1;      
		     break;      
		    }      
		   }      
		   if(flag==0)  { System.out.println(n+" is prime number"); }  
		  }//end of else  
	}

}
