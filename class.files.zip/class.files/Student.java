package com;

public class Student {
int id;
String name;
int phone;
String course;

@Override
public String toString() {
	return "Student [id=" + id + ", name=" + name + ", phone=" + phone + ", course=" + course + "]";
}
public Student(int id, String name, int phone, String course) {
	super();
	this.id = id;
	this.name = name;
	this.phone = phone;
	this.course = course;
}

}



