package com.beans;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		Address addr=(Address)context.getBean("aBean");
		System.out.println("HNO : "+addr.getHno());
		System.out.println("Address Line1 : "+addr.getLine1());
		System.out.println("City : "+addr.getCity());
		
		Employee e=(Employee)context.getBean("eBean");
		System.out.println("Eno : "+e.getEno());
		System.out.println("Name : "+e.getName());
		System.out.println("Address : "+e.getAddress().getHno()+"\t"+e.getAddress().getLine1()+"\t"+e.getAddress().getCity());

	}

}
