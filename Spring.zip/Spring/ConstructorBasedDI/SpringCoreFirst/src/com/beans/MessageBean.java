package com.beans;

public class MessageBean
{
   String message;
   
   public MessageBean()
     {}
   
   public String getMessage()
   {
	   return this.message;
   }
   public void setMessage(String message)
   {
	   this.message=message;
   }
}
