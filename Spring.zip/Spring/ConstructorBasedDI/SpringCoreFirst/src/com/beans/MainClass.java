package com.beans;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;

public class MainClass 
  {

	public static void main(String[] args) 
	{
	 // AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
	  //MessageBean mBean=(MessageBean)context.getBean("messageBean");//creation time-injected
	  
		BeanFactory factory=new XmlBeanFactory(new ClassPathResource("beans.xml"));
		MessageBean mBean=(MessageBean)factory.getBean("messageBean");
		System.out.println(mBean.getMessage());

	}

}
