package com.beans;

public class ByeBean {
	
	public ByeBean() {}
	
	public String sayBye()
	{
		return "Bye-Bye!Happy Learning...";
	}

}
