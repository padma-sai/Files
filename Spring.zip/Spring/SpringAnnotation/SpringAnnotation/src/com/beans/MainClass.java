package com.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) {
    ApplicationContext context=new AnnotationConfigApplicationContext(HelloBeanConfig.class);
    HelloBean bean=(HelloBean)context.getBean("helloBean");
    bean.setMsg("Hi! I am using annotations for configuration of bean..");
    System.out.println(bean.getMsg());
    
    ByeBean bb=(ByeBean)context.getBean("bBean");
    System.out.println(bb.sayBye());

	}

}
