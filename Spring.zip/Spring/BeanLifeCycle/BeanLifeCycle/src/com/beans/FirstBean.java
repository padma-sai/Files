package com.beans;

public class FirstBean 
{
   String message;
   
   public FirstBean() {}

  public String getMessage() {
	return message;  
    }

   public void setMessage(String message) {
	   this.message = message;
     }
   
   public void init()
   {
	   System.out.println("Bean is initialized....");
   }
   public void destroy()
   {
	   System.out.println("Bean is being destroyed....");
   }
}
