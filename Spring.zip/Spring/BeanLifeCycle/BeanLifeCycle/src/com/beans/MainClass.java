package com.beans;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		FirstBean bean=(FirstBean)context.getBean("firstBean");
		System.out.println("Message : "+bean.getMessage());
		
		SecondBean sBean=(SecondBean)context.getBean("secondBean");
		System.out.println("Message : "+sBean.getMessage());
        context.registerShutdownHook();
	}

}
