package com.beans;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;

public class MainClass 
  {

	public static void main(String[] args) 
	{
	 // AbstractApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
	  //MessageBean mBean=(MessageBean)context.getBean("messageBean");//creation time-injected
	  
		BeanFactory factory=new XmlBeanFactory(new ClassPathResource("beans.xml"));
		MessageBean mBean=(MessageBean)factory.getBean("messageBean");
		System.out.println(mBean.getMessage());

	}

}
==============================
<?xml version = "1.0" encoding = "UTF-8"?>

<beans xmlns = "http://www.springframework.org/schema/beans"
   xmlns:xsi = "http://www.w3.org/2001/XMLSchema-instance"
   xsi:schemaLocation = "http://www.springframework.org/schema/beans
   http://www.springframework.org/schema/beans/spring-beans-3.0.xsd">

   <bean id ="itBean" class = "entity.Item" >
    
         <property name = "itemid" value = "1234"/>
          <property name = "itemName" value = "UPS"/>
           <property name = "price" value = "5000"/>
           
   </bean>

</beans>
