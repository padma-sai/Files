package entity;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/Update")
public class Update extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			int wid = Integer.parseInt(request.getParameter("wid"));
			String wname = request.getParameter("wname");
			int salary = Integer.parseInt(request.getParameter("salary"));
			Worker wr = new Worker();
			wr.setWid(wid);
			wr.setWname(wname);
			wr.setSalary(salary);
			try{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			    System.out.println("Driver loaded successfully..");
			    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
			    System.out.println("Connection established successfully...");
			    String sql = "update worker set wname=?,salary=? where wid=?";
			    PreparedStatement st = con.prepareStatement(sql);
			    st.setString(1,wr.getWname());
			    st.setInt(2, wr.getSalary());
			    st.setInt(3,wr.getWid());
			    int rs = st.executeUpdate();
			    System.out.println(rs);
			    if(rs>0){
			 	   con.commit();
			 	  response.sendRedirect("Home.html");
			 	   System.out.println("Updated");
			}
			    else{
			    	 response.sendRedirect("Update.html");
			    	System.out.println("Failed");
			    }
			}
			catch(Exception e){
				System.out.println(e);
			}
	}

}
