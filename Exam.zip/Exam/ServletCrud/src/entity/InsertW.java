package entity;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/InsertW")
public class InsertW extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		int wid=Integer.parseInt(request.getParameter("wid"));
		String wname=request.getParameter("wname");
		int salary=Integer.parseInt(request.getParameter("salary"));
		
		Worker wr= new Worker();
		wr.setWid(wid);
		wr.setWname(wname);
		wr.setSalary(salary);
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		    System.out.println("Driver loaded successfully..");
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
		    System.out.println("Connection established successfully...");
		    String sql = "insert into worker values(?,?,?)";
		    PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, wr.getWid());
            st.setString(2, wr.getWname());
            st.setInt(3, wr.getSalary());
            
            int rs=st.executeUpdate();
            if(rs>0){
            	 con.commit();
            	 
            	 response.sendRedirect("Home.html");
  		 	   System.out.println("Inserted");
  		}
  		    else{
  		    	 response.sendRedirect("Insert.html");
  		    	System.out.println("Failed");
  		    }
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

}
