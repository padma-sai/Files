package entity;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/DeleteW")
public class Delete extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int wid=Integer.parseInt(request.getParameter("wid"));

		Worker wr= new Worker();
		wr.setWid(wid);
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		    System.out.println("Driver loaded successfully..");
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
		    System.out.println("Connection established successfully...");
		    String sql = "delete from worker where wid=?";
		    PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, wr.getWid());
            int rs=st.executeUpdate();
            System.out.println(rs);
            if(rs>0){
            	 con.commit();
            	 response.sendRedirect("Home.html");
  		 	   System.out.println("record is deleted");
  		}
  		    else{
  		    	 response.sendRedirect("Delete.html");
  		    	System.out.println("Failed");
  		    }
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

}
