package entity;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/View")
public class View extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int wid = Integer.parseInt(request.getParameter("wid"));
		Worker wr = new Worker();
		wr.setWid(wid);
		PrintWriter out = response.getWriter();  
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		    System.out.println("Driver loaded successfully..");
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
		    System.out.println("Connection established successfully...");
		    String sql = "select * from worker where wid=?";
		    PreparedStatement st = con.prepareStatement(sql);
		    st.setInt(1,wr.getWid());
		    ResultSet rs=st.executeQuery();  
		    System.out.println(rs);  
		    while(rs.next())  
		    {  
		    	 response.sendRedirect("Home.html");
		    	out.print(rs);
		    	out.print("Worker ID:"+rs.getInt(1)+"\nWorker NAME:"+rs.getString(2)+"\nSalary:"+rs.getInt(3));                   
		    }  
		}
		catch(Exception e){
			System.out.println(e);
		}
	}

}
