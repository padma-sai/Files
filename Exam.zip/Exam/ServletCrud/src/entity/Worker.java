package entity;

public class Worker {

	int wid;
	String wname;
	int salary;
	
	public Worker(){}
	
	

	public Worker(int wid, String wname, int salary) {
		super();
		this.wid = wid;
		this.wname = wname;
		this.salary = salary;
	}



	public int getWid() {
		return wid;
	}

	public void setWid(int wid) {
		this.wid = wid;
	}

	public String getWname() {
		return wname;
	}

	public void setWname(String wname) {
		this.wname = wname;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Worker [wid=" + wid + ", wname=" + wname + ", salary=" + salary + "]";
	}
	
	
}
