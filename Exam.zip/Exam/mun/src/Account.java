import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
import com.Details;
public class Account {
	public static void main(String[] args){
try{
	Scanner sc = new Scanner(System.in);
	System.out.println("Select one option\n1.INSERT\n2.UPDATE\n3.DELETE");
	int o = sc.nextInt();
	switch(o){
	case 1:
		
		System.out.println("Enter ACCID");
		int id = sc.nextInt();
		System.out.println("Enter Balance");
		int bal = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Name");
		String name=sc.next();
		
		Details d = new Details();
		d.setAccno(id);
		d.setName(name);
		d.setBalance(bal);
	Class.forName("oracle.jdbc.driver.OracleDriver");
    System.out.println("Driver loaded successfully..");
    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
    System.out.println("Connection established successfully...");
    String sql = "insert into accountss values(?,?,?)";
    PreparedStatement st = con.prepareStatement(sql);
    st.setInt(1,d.getAccno());
    st.setString(2,d.getName());
    st.setInt(3,d.getBalance());
    int rs = st.executeUpdate();
    System.out.println(rs);
    if(rs>0){
 	   con.commit();
 	   System.out.println("Inserted");
}
    break;
	case 2:
		System.out.println("Enter new ACCID");
		int i = sc.nextInt();
		System.out.println("Enter new Balance");
		int ba = sc.nextInt();
		String nam = "boys";
		Details de = new Details();
		de.setAccno(i);
		de.setName(nam);
		de.setBalance(ba);
    String sq = "update accountss set accno=? ,name =?, balance=?";
    Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
    PreparedStatement sts = conn.prepareStatement(sq);
    sts.setInt(1,de.getAccno());
    System.out.println(de.getAccno());
    sts.setString(2,de.getName());
    System.out.println(de.getName());
    sts.setInt(3,de.getBalance());
    System.out.println(de.getBalance());
    int rsw = sts.executeUpdate();
    System.out.println(rsw);
    if(rsw>0){
 	   conn.commit();   
 	  System.out.println("Updated");
}
    break;
	case 3:
		System.out.println("Enter  ACCId you want to delete");
		int g = sc.nextInt();
		Details des = new Details();
		des.setAccno(g);
    String s = "delete from accountss where accno=?";
    Connection co=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
    PreparedStatement sg = co.prepareStatement(s);
    sg.setInt(1,des.getAccno());
    System.out.println(des.getAccno());
    int rswr = sg.executeUpdate();
    System.out.println(rswr);
    if(rswr>0){
 	   co.commit();   
 	  System.out.println("deleted");
}
    break;
	}
}
catch(Exception e){
	System.out.println(e);
}

}
}
