package main;

import java.util.ArrayList;
import java.util.List;

public class Student {

	int regNo;
	String name;
	long phone;
	String Course;
	
	public Student(){}
	
	

	public Student(int regNo, String name, long phone, String course) {
		super();
		this.regNo = regNo;
		this.name = name;
		this.phone = phone;
		Course = course;
	}



	public int getRegNo() {
		return regNo;
	}

	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public String getCourse() {
		return Course;
	}

	public void setCourse(String course) {
		Course = course;
	}



	@Override
	public String toString() {
		return "Student [regNo=" + regNo + ", name=" + name + ", phone=" + phone + ", Course=" + Course + "]";
	}
	
	public static void main(String args[]){
	
		Student st = new Student(100,"Padma sai",934035534,"C++");
		Student st1 = new Student(101,"Geetha",678535534,"Python");
		Student st2 = new Student(102,"Niha",854435534,"Java");
		Student st3 = new Student(103,"Muni",696035534,"C++");
		Student st4 = new Student(104,"Hemu",999035534,"Java");
		
		List<Student> arr = new ArrayList<>();
		arr.add(st);
		arr.add(st1);
		arr.add(st2);
		arr.add(st3);
		arr.add(st4);
		
		System.out.println(".......Student Details........");
		for(Student sr:arr){			
			System.out.println(arr);
		}
	}
}
