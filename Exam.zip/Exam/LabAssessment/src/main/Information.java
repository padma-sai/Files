package main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


	class Details{
		String name;
	    long aadharid;
	    String city;
	    String state;
	    int pincode;
	    int noofdependents;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public long getAadharid() {
			return aadharid;
		}
		public void setAadharid(long aadharid) {
			this.aadharid = aadharid;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public int getPincode() {
			return pincode;
		}
		public void setPincode(int pincode) {
			this.pincode = pincode;
		}
		public int getNoofdependents() {
			return noofdependents;
		}
		public void setNoofdependents(int noofdependents) {
			this.noofdependents = noofdependents;
		}
		@Override
		public String toString() {
			return "Details [name=" + name + ", aadharid=" + aadharid + ", city=" + city + ", state=" + state
					+ ", pincode=" + pincode + ", noofdependents=" + noofdependents + "]";
		}
	    
		
	}

public class Information {
	
public static void main(String args[]) throws IOException ,SQLException, ClassNotFoundException{
		
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
        System.out.println("connection established");
		Scanner sc = new Scanner(System.in);
		 System.out.println("Enter your name: ");
         String name=sc.nextLine();
         System.out.println("Enter your aadharId: ");
         long aadhar=Integer.parseInt(sc.nextLine());
         System.out.println("Enter your city: ");
         String city=sc.nextLine();
         System.out.println("Enter your state: ");
         String state=sc.nextLine();
         System.out.println("Enter your pinCode: ");
         int pinCode=Integer.parseInt(sc.nextLine());
         System.out.println("Enter no of dependents: ");
         int noofdependents=Integer.parseInt(sc.nextLine());
         
         Details ad=new Details();
         ad.setName(name);
         ad.setAadharid(aadhar);
         ad.setCity(city);
         ad.setState(state);
         ad.setPincode(pinCode);
         ad.setNoofdependents(noofdependents);
         
        
         String sql="insert into information values(?,?,?,?,?,?)";
         PreparedStatement ps=con.prepareStatement(sql);
         ps.setString(1,ad.getName());
         ps.setLong(2, ad.getAadharid());
         ps.setString(3,ad.getCity());
         ps.setString(4, ad.getState());
         ps.setInt(5, ad.getPincode());
         ps.setInt(6, ad.getNoofdependents());
         
         ps.execute();
         System.out.println("Records are inserted");
         ResultSet result = ps.executeQuery("select * from information");
         
         while(result.next())
         {
             System.out.println(result.getString(1) +"  " +result.getLong(2) +"  " +result.getString(3) +"  " +result.getString(4)+"  " +result.getInt(5)+ " " + result.getInt(6));
         }
     }
         catch(Exception e)   
         {    
             e.printStackTrace();
         }
	
		
		
}
}
