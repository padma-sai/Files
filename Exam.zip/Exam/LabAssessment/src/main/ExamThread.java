package main;


class front extends Thread{
	public void run(){
		for (int i=1;i<=10;i++){
			System.out.println(i);
		}
	}
}

class back extends Thread{
	public void run(){
		for(int i=10;i>=1;i--){
			System.out.println(i);
		}
	}
}
public class ExamThread {

public static void main(String args[]){
		
		front fr = new front();
	    back bc = new back();
		
	    fr.start();
		bc.start();
	}
}
