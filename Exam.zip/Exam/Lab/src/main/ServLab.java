package main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServLab
 */
@WebServlet("/ServLab")
public class ServLab extends HttpServlet {

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		

		response.setContentType("text/html");
		
		PrintWriter pw = response.getWriter();
		
		String Fullname=request.getParameter("fullname");
		String email = request.getParameter("email");
		int mobileno = Integer.parseInt(request.getParameter("mobileno"));
		String gender = request.getParameter("gender");
		String city = request.getParameter("city");
	
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			
			PreparedStatement ps= conn.prepareStatement("Insert into man values(?,?,?,?,?)");
			
			ps.setString(1,Fullname);
			ps.setString(2,email);
			ps.setInt(3, mobileno);
			ps.setString(4, gender);
			ps.setString(5, city);
			
			int i= ps.executeUpdate();
			if(i>0){
				pw.println("Records are inserted");
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	
	}
	
	
	

}
