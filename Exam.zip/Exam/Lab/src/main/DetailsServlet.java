package main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DetailsServlet
 */
@WebServlet("/DetailsServlet")
public class DetailsServlet extends HttpServlet {
	
	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		

		response.setContentType("text/html");
		
		PrintWriter pw = response.getWriter();
		
		String Name=request.getParameter("name");
		System.out.println(Name);
		long Aadharid = Long.parseLong(request.getParameter("aadharid"));
		System.out.println(Aadharid);
		String City = request.getParameter("city");
		System.out.println(City);
		String State = request.getParameter("state");
		System.out.println(State);
		int Pincode =Integer.parseInt( request.getParameter("pincode"));
		System.out.println(Pincode);
		int noofdependents =Integer.parseInt( request.getParameter("noofdependents"));
		System.out.println(noofdependents);
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			
			PreparedStatement ps= conn.prepareStatement("Insert into Information values(?,?,?,?,?,?)");
			
			ps.setString(1,Name);
			ps.setLong(2,Aadharid);
			ps.setString(3,City);
			ps.setString(4,State);
			ps.setInt(5,Pincode);
			ps.setInt(6, noofdependents);
			
			int i= ps.executeUpdate();
			if(i>0){
				pw.println("Records are inserted");
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	
	}
}
