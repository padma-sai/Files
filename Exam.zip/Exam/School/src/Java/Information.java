package Java;

 

import java.sql.*;
import java.util.*;

 

public class Information{
          Connection conn;
            public Information()
            {
                try
                {
                Class.forName("oracle.jdbc.driver.OracleDriver");  
                conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
                
                System.out.println("connection established");  
                
                Scanner tomt = new Scanner(System.in);  
                Statement stmt = conn.createStatement(); 
                
                System.out.println("ENTER NAME");
                String Name=tomt.next();
                
                System.out.println("ENTER AadhraID");
                long AadhraID=tomt.nextLong();
                
                System.out.println("ENTER City");
                String City=tomt.next();
                
                System.out.println("ENTER State");
                String State=tomt.next();
                
                System.out.println("ENTER Pincode");
                int Pincode=tomt.nextInt();
                
                System.out.println("ENTER NoofDependents");
                int NoofDependents=tomt.nextInt();
                
                PreparedStatement pstmt = conn.prepareStatement("insert into Information values (?,?,?,?,?,?)");
                pstmt.setString(1,Name);
                pstmt.setLong(2,AadhraID);
                pstmt.setString(3,City);
                pstmt.setString(4,State);
                pstmt.setInt(5,Pincode);
                pstmt.setInt(6, NoofDependents);
                pstmt.execute();
                ResultSet result = stmt.executeQuery("select * from Information");
                
                while(result.next())
                {
                    System.out.println("Details = "+result.getString(1) +"  " +result.getLong(2) +"  " +result.getString(3) +"  " +result.getString(4)+"  " +result.getInt(5)+ " " + result.getInt(6));
                }
            }
                catch(Exception e)   
                {    
                    e.printStackTrace();
                }
            }
            public static void main(String[]args)
            {
                new Information();
            }
        }