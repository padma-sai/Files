package main;

class Normalchar extends Thread{
	public void run(){
	
		for (char i='a';i<='z';i++){
			System.out.println("NormalChar " +i);
		}
			
		}
	}

class Reversechar extends Thread{
	public void run(){
		for (int j=1;j<30;j++){
			System.out.println("ReverseChar "+j);
		}
	}
	
}
public class LabThread {
	
	public static void main(String args[]){
		
		Normalchar n = new Normalchar();
	    Reversechar r = new Reversechar();
		
	    n.start();
		r.start();
	}

}
