package main;

import java.util.ArrayList;
import java.util.Collection;

public class LabCollection {

	public static void main(String args[]){
		ArrayList<Book> arr = new ArrayList<Book>();
		
		Book bo1 = new Book(121,"Bibile",1300);
		Book bo2 = new Book(122,"Doremon",500);
		Book bo3 = new Book(123,"Island",800);
		Book bo4 = new Book(124,"Pink Panter",1500);
		Book bo5 = new Book(125,"Ramayanam",400);

	
		arr.add(bo1);
		arr.add(bo2);
		arr.add(bo3);
		arr.add(bo4);
		arr.add(bo5);
	
		
		for(Book val:arr){
			System.out.println(val);
		}
	}
}
