package main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Account {

	public static void main(String args[]) throws IOException ,SQLException, ClassNotFoundException{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
		
		if(conn!=null)
			System.out.println("connected");
		Statement stm=conn.createStatement();
		Scanner sc = new Scanner(System.in);
		System.out.println("Select one option\n1.Create table\n2.Insert Data\n3.Update\n4.Delete\n5.Exit");
		int o = sc.nextInt();		
			switch(o)
		
		{
		case 1:
			stm.executeUpdate("Create table Account(Accno number primary key,name varchar2(20),Balance number)");
			System.out.println("table created");
			  conn.commit();   
			break;
			
		case 2:
			stm.executeUpdate("insert into Account values(1,'padmasai',10000)");
			stm.executeUpdate("insert into Account values(2,'Getha',9000)");
			stm.executeUpdate("insert into Account values(4,'Siva',20000)");
			System.out.println("data are inserted");
			  conn.commit(); 
			break;
		case 3:
			stm.executeUpdate("update account set balance=23000 where accno=1");
			System.out.println("Record updated");
			  conn.commit(); 
			
			break;
			
		case 4:
			stm.executeUpdate("delete account wherre id =2");
			System.out.println("Record deleted");
			  conn.commit(); 
		break;
		case 5:
			System.exit(0);
			System.out.println("Exited");
			
		
		}
	}
}
