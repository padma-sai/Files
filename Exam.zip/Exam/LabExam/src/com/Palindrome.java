package com;
public class Palindrome 
{ 


public static int Pal(int n) 
    { 
          int rev = 0; 
        for (int i = n; i > 0; i /= 10) 
            rev = rev * 10 + i % 10; 
      
        return(n == rev) ? 1 : 0; 
    } 
      
   
    public static void countPal(int min, int max) 
    { int count=0;
    int i = 0;
        for ( i = min; i <= max; i++) 
            if (Pal(i)==1) 
                System.out.print(i + " ");
        count=i;
        System.out.println(count);
    } 
     
  
    public static void main(String args[]) 
    { 
    
        countPal(200, 500); 
    }
}
