package com.hcl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
public class LoginController {

	
LoginValidator loginvalidator;
@Autowired	
 public LoginController(LoginValidator loginvalidator) {
	this.loginvalidator= loginvalidator;
	}
	
	@RequestMapping("/login")
	public String getLoginForm(Map<String, Object> model, User user)
	{
	
		model.put("loginForm", user);
	return "LoginPage";
	}


	@RequestMapping("/submit")
	public String submitLoginForm(@ModelAttribute("loginForm") User user, Errors errors)
	{
        loginvalidator.validate(user, errors);
		if(errors.hasErrors())
		{
		return "LoginPage";
	
		}
	
		return "loginsuccess";

	}

}