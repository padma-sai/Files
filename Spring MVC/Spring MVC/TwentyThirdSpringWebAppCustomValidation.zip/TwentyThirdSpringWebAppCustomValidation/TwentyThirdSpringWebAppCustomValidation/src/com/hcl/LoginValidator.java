package com.hcl;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class LoginValidator implements Validator{

	@Override
	public boolean supports(Class<?> arg0) {
	
	return User.class.isAssignableFrom(arg0);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "username.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "password.required");
		
		/*  User user =(User)target;
	
		  System.out.println(user.getUsername().length());
		if(user.getUsername().length()==0)
		{
			errors.rejectValue("username", "username.required");
		}
		
		if(user.getPassword().length()==0)
		{
			errors.rejectValue("password", "password.required");
		}
		*/
	}

	
}
