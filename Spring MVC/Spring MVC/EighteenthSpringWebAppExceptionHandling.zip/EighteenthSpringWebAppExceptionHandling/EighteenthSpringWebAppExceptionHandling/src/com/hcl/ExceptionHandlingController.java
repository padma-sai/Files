package com.hcl;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ExceptionHandlingController {

	@RequestMapping("/trainee")
	public String processRequest()
	{
	String str="SERVLET";

	if (str.equals("NULL"))
	{
		throw new NullPointerException("Null Pointer Exception is occured");
		
	}
	else if (str.equals("ARITH"))
	{
		throw new ArithmeticException("Arithmetic Excepion Occured");
	}
	else if (str.equals("NUM"))
	{
		throw new NumberFormatException("Number Format Excepion Occured");
	}
	return "welcome";
	}
	

	@ExceptionHandler(NullPointerException.class)
	 public ModelAndView handleNullPointerException(NullPointerException e)
	 {
		
		String classname=e.getClass().getName();
		String message = e.getMessage();
		ModelAndView mnv = new ModelAndView("nullexcpage");
		mnv.addObject("classname", classname);
		mnv.addObject("message", message);
		return mnv;
		 
	 }
	
	@ExceptionHandler(NumberFormatException.class)
	 public ModelAndView handleNumberFormatException(NumberFormatException e)
	 {
		
		String classname=e.getClass().getName();
		String message = e.getMessage();
		ModelAndView mnv = new ModelAndView("nullexcpage");
		mnv.addObject("classname", classname);
		mnv.addObject("message", message);
		return mnv;
		 
	 }
	
	@ExceptionHandler(Exception.class)
	 public ModelAndView handleException(Exception e)
	 {
		
		String classname=e.getClass().getName();
		String message = e.getMessage();
		ModelAndView mnv = new ModelAndView("nullexcpage");
		mnv.addObject("classname", classname);
		mnv.addObject("message", message);
		return mnv;
		 
	 }
	


}
