package com.hcl;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TraineeController {

@RequestMapping("/trainee/{traineeid}/{trname}")
public String processRequest(@PathVariable("traineeid") String tid, @PathVariable("trname") String tname, Model model)
{
	System.out.println(tid);	
	System.out.println(tname);	

	model.addAttribute("tid", tid);
	model.addAttribute("tname", tname);


	return "welcome";
}
}
