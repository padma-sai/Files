package com.hcl;

public class Trainee {
private String traineeid;
private String tname;
private String city;
public String getTraineeid() {
	return traineeid;
}

public void setTraineeid(String traineeid) {
	this.traineeid = traineeid;
}

public String getTname() {
	return tname;
}
public void setTname(String tname) {
	this.tname = tname;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}


}
