package com.hcl;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TraineeController {

	@RequestMapping("addtrainee")
	public String processRequest(Model model, Trainee trainee )
	{
       model.addAttribute("message", "Hello! POJO has been populated using form values!");
       System.out.println(trainee.getTraineeid());
       System.out.println(trainee.getTname());
       System.out.println(trainee.getCity());
       return "welcome";
	
	}
	
	@RequestMapping("/index.html")
	public String homeRequest()
	{
		return "index";
	}
}
